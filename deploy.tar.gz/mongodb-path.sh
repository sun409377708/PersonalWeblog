export PATH="/Users/maoge/Desktop/windsurf/FirstProduct/mongodb-macos-x86_64-8.0.3/bin:$PATH"
